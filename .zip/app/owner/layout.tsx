
'use client';

import React, {
  Suspense,
  useEffect,
  useState,
} from 'react';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

import {
  Home,
  Package,
  Boxes,
  BookOpen,
  Truck,
  ShoppingBag,
  ClipboardList,
  FileText,
  UserCheck,
  LogOut,
} from 'lucide-react';

// ==========================================
// TYPE PROFILE
// ==========================================

type Profile = {
  nama: string;
  role: string;
  avatar_url?: string | null;
};

// ==========================================
// HELPER FUNCTIONS
// ==========================================

function getInitials(nama: string) {
  return (
    nama
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((word) => word[0])
      .join('')
      .toUpperCase() || 'U'
  );
}

function formatRole(role: string) {
  return role
    .split(/\s+/)
    .map(
      (word) =>
        word.charAt(0).toUpperCase() + word.slice(1)
    )
    .join(' ');
}

// ==========================================
// MENU OWNER
// ==========================================

const menuItems = [
  { name: 'Home Page', href: '/owner', icon: Home },
  { name: 'Data Produk', href: '/owner/produk', icon: Package },
  { name: 'Data Bahan Baku', href: '/owner/bahan-baku', icon: Boxes },
  { name: 'Resep', href: '/owner/resep', icon: BookOpen },
  { name: 'Data Supplier', href: '/owner/supplier', icon: Truck },
  {
    name: 'Pemesanan Bahan Baku',
    href: '/owner/pemesanan-bahan-baku',
    icon: ShoppingBag,
  },
  { name: 'Pesanan', href: '/owner/pesanan', icon: ClipboardList },
  {
    name: 'Laporan',
    sub: 'Harian & Bulanan',
    href: '/owner/laporan',
    icon: FileText,
  },
];

// ==========================================
// OWNER LAYOUT CLIENT
// ==========================================

function OwnerLayoutContent({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const [profile, setProfile] = useState<Profile | null>(null);

  // ========================================
  // LOAD PROFILE FROM DATABASE
  // ========================================

  useEffect(() => {
    const controller = new AbortController();

    async function loadProfile() {
      try {
        const response = await fetch('/api/auth/me', {
          method: 'GET',
          cache: 'no-store',
          credentials: 'same-origin',
          signal: controller.signal,
        });

        const result = await response.json();

        if (
          !response.ok ||
          !result.success ||
          !result.data
        ) {
          throw new Error(
            result.error || 'Gagal mengambil profil.'
          );
        }

        setProfile({
          nama: result.data.nama || 'Pengguna',
          role: result.data.role || 'owner',
          avatar_url: result.data.avatar_url || null,
        });
      } catch (error) {
        if (!controller.signal.aborted) {
          console.error(
            'Gagal memuat profil Owner:',
            error
          );
        }
      }
    }

    loadProfile();

    return () => {
      controller.abort();
    };
  }, [pathname]);

  // ========================================
  // CHECK ACTIVE MENU
  // ========================================

  function isMenuActive(href: string) {
    if (href === '/owner') {
      return pathname === '/owner';
    }

    return (
      pathname === href ||
      pathname.startsWith(href + '/')
    );
  }

  // ========================================
  // MAIN LAYOUT
  // ========================================

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        width: '100%',
        backgroundColor: '#e59cae',
        fontFamily: 'system-ui, sans-serif',
        overflow: 'hidden',
      }}
    >
      {/* SIDEBAR */}

      <aside
        style={{
          width: '240px',
          backgroundColor: '#e59cae',
          padding: '20px 16px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          height: '100vh',
          flexShrink: 0,
          boxSizing: 'border-box',
        }}
      >
        <div>
          <h2
            style={{
              color: '#ffffff',
              fontSize: '20px',
              fontWeight: 'bold',
              marginBottom: '24px',
              paddingLeft: '8px',
            }}
          >
            Menu Owner
          </h2>

          <nav
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
            }}
          >
            {menuItems.map((item) => {
              const Icon = item.icon;
              const active = isMenuActive(item.href);

              return (
                <Link
                  key={item.name}
                  href={item.href}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '10px 16px',
                    borderRadius: '12px',
                    textDecoration: 'none',
                    fontWeight: 600,
                    fontSize: '13px',
                    backgroundColor: active
                      ? '#a02e59'
                      : '#ffffff',
                    color: active
                      ? '#ffffff'
                      : '#ac3562',
                    boxShadow:
                      '0 2px 4px rgba(0,0,0,0.05)',
                  }}
                >
                  <Icon size={18} />

                  <div>
                    <div>{item.name}</div>

                    {item.sub && (
                      <div
                        style={{
                          fontSize: '9px',
                          opacity: 0.8,
                          marginTop: '-2px',
                        }}
                      >
                        {item.sub}
                      </div>
                    )}
                  </div>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* BOTTOM BUTTONS */}

        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            marginTop: '20px',
          }}
        >
          <Link
            href="/owner/profil"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '10px 16px',
              borderRadius: '20px',
              backgroundColor: isMenuActive('/owner/profil')
                ? '#a02e59'
                : '#ffffff',
              color: isMenuActive('/owner/profil')
                ? '#ffffff'
                : '#a02e59',
              textDecoration: 'none',
              fontSize: '13px',
              fontWeight: 'bold',
            }}
          >
            <UserCheck size={16} />
            Edit Profil
          </Link>

          <Link
            href="/owner/logout"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '10px 16px',
              borderRadius: '20px',
              backgroundColor: pathname === '/owner/logout'
                ? '#a02e59'
                : '#ffffff',
              color: pathname === '/owner/logout'
                ? '#ffffff'
                : '#a02e59',
              textDecoration: 'none',
              fontSize: '13px',
              fontWeight: 'bold',
            }}
          >
            <LogOut size={16} />
            Log out
          </Link>
        </div>
      </aside>

      {/* AREA KANAN */}

      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          height: '100vh',
          overflow: 'hidden',
          minWidth: 0,
        }}
      >
        {/* HEADER */}

        <header
          style={{
            backgroundColor: '#a02e59',
            height: '70px',
            padding: '0 32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            color: '#ffffff',
            flexShrink: 0,
          }}
        >
          <h1
            style={{
              fontSize: '24px',
              fontWeight: 'bold',
              margin: 0,
            }}
          >
            Home Page
          </h1>

          {/* PROFILE */}

          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
            }}
          >
            <div style={{ textAlign: 'right' }}>
              <div
                style={{
                  fontSize: '13px',
                  fontWeight: 'bold',
                }}
              >
                {profile?.nama || 'Memuat profil...'}
              </div>

              <div
                style={{
                  fontSize: '11px',
                  opacity: 0.8,
                }}
              >
                {profile
                  ? formatRole(profile.role)
                  : 'Owner'}
              </div>
            </div>

            {/* AVATAR */}

            <div
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '50%',
                backgroundColor: '#ffffff',
                color: '#a02e59',
                fontWeight: 'bold',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '14px',
                overflow: 'hidden',
                flexShrink: 0,
              }}
            >
              {profile?.avatar_url ? (
                <img
                  src={profile.avatar_url}
                  alt="Avatar Owner"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                  }}
                />
              ) : (
                getInitials(profile?.nama || 'Owner')
              )}
            </div>
          </div>
        </header>

        {/* MAIN CONTENT */}

        <main
          style={{
            flex: 1,
            padding: '24px 32px',
            overflowY: 'auto',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px',
            minHeight: 0,
          }}
        >
          {children}

          <footer
            style={{
              padding: '12px 0',
              fontSize: '11px',
              color: '#702643',
              marginTop: 'auto',
            }}
          >
            Akses Owner · Lihat detail dan beri persetujuan
          </footer>
        </main>
      </div>
    </div>
  );
}

// ==========================================
// OWNER LAYOUT - SUSPENSE BOUNDARY
// ==========================================

export default function OwnerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#e59cae',
            color: '#702643',
            fontFamily: 'system-ui, sans-serif',
          }}
        >
          Memuat halaman Owner...
        </div>
      }
    >
      <OwnerLayoutContent>
        {children}
      </OwnerLayoutContent>
    </Suspense>
  );
}
